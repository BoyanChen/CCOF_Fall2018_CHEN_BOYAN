//
//  Clock.cpp
//  MeshesLearning11_24
//
//  Created by Ronnie Chen on 12/3/18.
//

#include "Clock.hpp"

void Clock::setup(ofPoint pos, float radius){
    
    ofBackground(255);
    loc = pos;
    r = radius;
    rHh = 0.3 * r;
    rMh = 0.7 * r;
    
    velHhDeg = ofRandom(0,360);
    velMhDeg = ofRandom(0,360);
    
    velHh = 0.01;
    velMh = 0.6;
    
    
    hourH.set(loc.x +rHh*cos(ofDegToRad(velHhDeg)),loc.y+ rHh*sin(ofDegToRad(velHhDeg)),loc.z);
    minH.set(rMh*cos(ofDegToRad(velMhDeg)), rMh*sin(ofDegToRad(velMhDeg)),loc.z);
    
}


void Clock::update(float timeChange){
    velHhDeg += velHh * timeChange;
    velMhDeg += velMh * timeChange;
    
    hourH.set(loc.x +rHh*cos(ofDegToRad(velHhDeg)), loc.y + rHh*sin(ofDegToRad(velHhDeg)),loc.z);
    minH.set(loc.x + rMh*cos(ofDegToRad(velMhDeg)),loc.y + rMh*sin(ofDegToRad(velMhDeg)),loc.z);
    
}

void Clock::draw(){
    

    
    ofSetColor(255);
    ofSetLineWidth(3);
    ofDrawLine(hourH.x, hourH.y,loc.z+1, loc.x, loc.y,loc.z+1);
//    ofDrawLine(hourH, loc);
    ofSetLineWidth(2);
    ofDrawLine(minH.x, minH.y, minH.z+1, loc.x, loc.y, loc.z+1);
    ofSetLineWidth(1);
    
    
}

//void Clock::locUpdate(ofPoint up){
//    loc.set(up);
//    hourH.set(loc.x +rHh*cos(ofDegToRad(velHhDeg)),loc.y+ rHh*sin(ofDegToRad(velHhDeg)),loc.z);
//    minH.set(rMh*cos(ofDegToRad(velMhDeg)), rMh*sin(ofDegToRad(velMhDeg)),loc.z);
//}
