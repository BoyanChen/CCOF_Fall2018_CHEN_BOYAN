//
//  Nova.hpp
//  MeshesLearning11_24
//
//  Created by Ronnie Chen on 11/25/18.
//

#ifndef Nova_hpp
#define Nova_hpp

#include <stdio.h>
#include "ofMain.h"

class Nova{
public:
    ofPoint origin;
    float radius;
    float angle;
    float angleVel;
    float roundRadius;
    ofColor c;
    
    void setup(int vMax);
    void draw();
    void update(ofPoint v);
    void isDead();
    
    float x;
    float y;
    ofPoint pivot;
    float angleZ;
    float w;
    float h;
    ofPoint pos;
    ofPoint vel;
    float mainRadius;
    
};


#endif /* Nova_hpp */
