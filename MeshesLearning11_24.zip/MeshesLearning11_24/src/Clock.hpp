//
//  Clock.hpp
//  MeshesLearning11_24
//
//  Created by Ronnie Chen on 12/3/18.
//

#ifndef Clock_hpp
#define Clock_hpp

#include <stdio.h>
#include "ofMain.h"

class Clock{
public:
    void setup(ofPoint pos, float radius);
    void update(float timeChange);
    void draw();
    void locUpdate(ofPoint up);
    
    ofPoint hourH;
    ofPoint minH;
    
    ofPoint loc;
    
    float velHhDeg;
    float velMhDeg;
    
    float velHh;
    float velMh;
    
    float rHh;
    float rMh;
    float r;
    
};

#endif /* Clock_hpp */
