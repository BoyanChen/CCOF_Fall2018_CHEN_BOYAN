//
//  Nova.cpp
//  MeshesLearning11_24
//
//  Created by Ronnie Chen on 11/25/18.
//

#include "Nova.hpp"


void Nova::setup(int vMax){
    w = 360;
    h = 360;
    mainRadius = 60;
    
    pos.set(ofRandom(-w/2,w/2),ofRandom(-h/2,h/2),3000);
    
    vel.set(0,0,ofRandom(2,vMax));
    c.set(ofRandom(0,255),ofRandom(0,255),ofRandom(0,255));
  
     }

void Nova::update(ofPoint v){
    pos += v*10;
    c.setHue(ofMap(pos.z, 0, 1000, 150, 255));

}

void Nova::draw(){

    float sat = ofMap(pos.z, -300, 500, 100, 255);
    c.setSaturation(sat);
    ofSetColor(c);
//    if(pos.z == -300){
//        ofDrawCircle(pos,100);
//    }
    ofDrawIcoSphere(pos, 2);
      ofSetColor(c,80);
    ofDrawIcoSphere(pos.x, pos.y, pos.z-0.5+5, 1.5);
          ofSetColor(c,50);
    ofDrawIcoSphere(pos.x, pos.y, pos.z-10.5, 1);
          ofSetColor(c,20);
    ofDrawIcoSphere(pos.x, pos.y, pos.z-12, 0.5);
    ofDrawIcoSphere(pos.x, pos.y, pos.z-22.5, 0.25);
    ofSetColor(c,20);
    ofDrawIcoSphere(pos.x, pos.y, pos.z-32, 0.125);
}

void Nova::isDead(){
    pos.set(ofRandom(-w/2,w/2),ofRandom(-h/2,h/2),-300);
}
