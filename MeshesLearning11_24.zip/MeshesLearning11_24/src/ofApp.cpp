#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    ofSetWindowShape(1080, 720);
//setup syphone video output
    
    mainOutputserver.setName("screen output");
    mClient.setup();
    mClient.setApplicationName("testSever");
    mClient.setServerName("");
    
    
    //light ball
    
    
    resolution = 120;
    

    
    gui.setup();
    gui.add(velocity.setup("velocity", 2, 0, 10));
    gui.add(novaNum.setup("num", 2000   , 0, 800));
    gui.add(facesNum.setup("Number of slices",4,4,10));
slicesNum = 4;
    
length = (facesNum-1) * resolution;

//assign basic Nova
size = 500;

//assign vertexes
    for (int z = 0; z < slicesNum; z++){
        for (int x = 0; x < facesNum; x++){
            for (int y = 0; y < facesNum; y++){
                mesh.addVertex(ofPoint(x*resolution - length/2, y*resolution - length/2,z*resolution - length/2));
            }
        }
    }

    cout<<clocks.size()<<endl;
    

//assign lines index
    for(int z = 0; z < slicesNum; z++){
    for (int y = 0; y<facesNum-1; y++){
        for (int x=0; x<facesNum-1; x++){
            mesh.addIndex(x+y*facesNum + z * facesNum * facesNum);               // 0
            mesh.addIndex((x+1)+y*facesNum + z * facesNum * facesNum);           // 1
            mesh.addIndex(x+(y+1)*facesNum + z * facesNum * facesNum);           // 4
            
            mesh.addIndex((x+1)+y*facesNum + z * facesNum * facesNum);           // 1
            mesh.addIndex((x+1)+(y+1)*facesNum + z * facesNum * facesNum);       // 5
            mesh.addIndex(x+(y+1)*facesNum + z * facesNum * facesNum);           // 4
        }
    }
    }
    
    //assign Nova
//
    for (int i =0; i < novaNum; i++){
        Nova n;
        n.setup(4);
        particles.push_back(n);
    }
    

//mover's radius
sphereRadius = 120;
    angle = 0;
copyMesh = mesh;
    copyClocks = clocks;
    mover.set(0, sphereRadius*cos(ofDegToRad(angle)),sphereRadius*sin(ofDegToRad(angle)));
shader.load( "","shader.frag");

}

//--------------------------------------------------------------
void ofApp::update(){
    
    ofSeedRandom(39);
    //
    
    
    angle += velocity;
        mover.set(sphereRadius*cos(ofDegToRad(angle)), 0,sphereRadius*sin(ofDegToRad(angle)));
    if(particles.size() < novaNum){
        size ++;
        Nova n;
        n.setup(3);
        particles.push_back(n);
    }


for (int i =0; i < particles.size(); i++){
if(particles[i].pos.z > 9000){
    particles.erase(particles.begin()+i);
}
//    cout<<particles.size()<<endl;
particles[i].update(ofPoint(0,0,velocity));
}
    

mesh = copyMesh;
for (int i =0; i < mesh.getVertices().size(); i++){
ofPoint vPos = mesh.getVertices()[i];

float dist = mover.distance(vPos);
//cout<<dist<<endl;
float displacement = ofMap(dist, 100, 500, 8*velocity, 0,true);
ofPoint dir = mover - vPos;
dir.normalize();
        mesh.setVertex(i, vPos + dir * displacement);

}

}

//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0);
//    shader.begin();
//    shader.setUniform2f("resolution", ofGetWindowWidth(), ofGetWindowHeight());
//    shader.setUniform1f("time", ofGetElapsedTimef()*(4/velocity));
//
//    ofRect(0,0,ofGetWindowWidth(),ofGetWindowHeight());
//    shader.end();

    ofEnableDepthTest();
//        ofBackgroundGradient(ofColor(0), uV);


    ofPushMatrix();

ofTranslate(ofGetWindowWidth()/2, ofGetWindowHeight()/2);



//assign Shader
float time = ofGetElapsedTimef();
float dt = ofClamp( time - time0, 0, 0.1 );
time0 = time;
//mover.set(sphereRadius*cos(time*velocity/2), 0, sphereRadius*sin(time*velocity/2));
float speed = ofMap( mover.y, 0, ofGetHeight(), 0, 5 );
phase += speed * dt;
distortAmount = ofMap( mover.x, 0, ofGetWidth(), 0, 1.0 );



//draw time space
    cam.begin();

//assign tuneral

    


    //draw Nova
    for (int i =0; i < particles.size(); i++){
        particles[i].draw();
    }

    //draw clocks
    //update clocks

//    for(int i = 0; i < clocks.size(); i++){
//        clocks[i].draw();
//    }
    shader.begin();
    shader.setUniform2f("resolution", ofGetWindowWidth(), ofGetWindowHeight());
    shader.setUniform1f("time", ofGetElapsedTimef()*(4/velocity));

    ofRotateY(180);
    
    int radius = 500;
    for (int i = 0; i < 8; i++) {
        
        float noise_param_1 = ofRandom(360);
        float noise_param_2 = ofRandom(360);
        glm::vec3 prev = glm::vec3();
        for (int len = 0; len < 200; len += 1) {
            
            int deg = noise_param_1 + ofNoise(noise_param_2, (ofGetFrameNum() + len) * 0.005) * 360;
            deg = (deg / 10) * 30;
            glm::vec3 location = glm::vec3(radius * cos(deg * DEG_TO_RAD), radius * sin(deg * DEG_TO_RAD), len * velocity
                                           );
            
            if (len != 0) {
                
                ofDrawLine(location, prev);
            }
            
            prev = location;
        }
        
        ofDrawSphere(prev, 3);
    }
    
//    ofRect(0,0,ofGetWindowWidth(),ofGetWindowHeight());
    ofSetColor(255);
    mesh.setMode(OF_PRIMITIVE_TRIANGLES);
    ofSetLineWidth(2);

    mesh.drawWireframe();
        shader.end();
//draw mover
    ofSetColor(255);
    ofDrawSphere(mover,20);
    cam.end();
    ofPopMatrix();
    ofDisableDepthTest();
    gui.draw();
    mClient.draw(50, 50);
    mainOutputserver.publishScreen();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
